# -*- coding: utf-8 -*-
"""Ponte Kotlin <-> CPython (Chaquopy): executa scripts com stdout/stderr/stdin em tempo real e analisa código."""
import ast
import builtins
import difflib
import gc
import json
import keyword
import linecache
import os
import queue
import sys
import threading
import time
import traceback
import types
import codeop
import importlib
import inspect
import io
import re

_real_sleep = time.sleep
_state = {"tid": None, "stop": False, "stdin": queue.Queue(), "presets": []}
_dbg = {"file": "", "bps": set(), "step": False, "cmd": queue.Queue()}
_sink = None
_BUILTIN_NAMES = set(dir(builtins)) | {
    "exit", "quit", "copyright", "credits", "license", "help",
    "__file__", "__name__", "__doc__", "__builtins__", "__spec__",
    "__loader__", "__package__", "__class__", "__debug__",
}


# ------------------------------------------------------------------ streams
# A saída é agrupada e entregue ao Kotlin em blocos (no máximo ~25x/s ou a cada 4 KB).
# Sem isso, um `while True: print(...)` gera milhões de chamadas JNI e trava o app.
_buf = []
_buf_len = 0
_buf_lock = threading.Lock()
_flush_lock = threading.RLock()
_FLUSH_AT = 4096


def _emit(name, text):
    global _buf_len
    with _buf_lock:
        _buf.append((name, text))
        _buf_len += len(text)
        big = _buf_len >= _FLUSH_AT
    if big:
        _flush()


def _flush():
    global _buf_len
    with _flush_lock:
        with _buf_lock:
            if not _buf:
                return
            items = _buf[:]
            del _buf[:]
            _buf_len = 0
        sink = _sink
        if sink is None:
            return
        cur = None
        parts = []
        for name, text in items:
            if name != cur:
                if parts:
                    sink.write(cur, "".join(parts))
                cur = name
                parts = [text]
            else:
                parts.append(text)
        if parts:
            sink.write(cur, "".join(parts))


def _flusher(ev):
    while not ev.wait(0.04):
        try:
            _flush()
        except BaseException:
            pass


class _Out:
    encoding = "utf-8"
    errors = "replace"

    def __init__(self, name):
        self._name = name

    def write(self, s):
        if not isinstance(s, str):
            s = str(s)
        if s:
            _emit(self._name, s)
        return len(s)

    def flush(self):
        pass

    def isatty(self):
        return False

    def writable(self):
        return True

    def fileno(self):
        raise OSError("fileno() não suportado")


class _In:
    encoding = "utf-8"

    def __init__(self):
        self._eof = False
        self._buf = ""

    def _fetch(self, prompt=""):
        """Bloqueia até o usuário enviar uma linha. Retorna a linha com '\\n' ou '' no EOF."""
        if self._eof:
            return ""
        pre = _state["presets"]
        if pre:
            line = pre.pop(0)
            _emit("in", line + "\n")
            return line + "\n"
        _flush()
        _sink.onInputRequested(str(prompt))
        while True:
            if _state["stop"]:
                raise KeyboardInterrupt
            try:
                item = _state["stdin"].get(timeout=0.1)
                break
            except queue.Empty:
                continue
        if _state["stop"]:
            raise KeyboardInterrupt
        _sink.onInputConsumed()
        if item is None:
            self._eof = True
            return ""
        return item + "\n"

    def readline(self, size=-1):
        line = self._buf or self._fetch()
        self._buf = ""
        if size is not None and size >= 0 and len(line) > size:
            self._buf = line[size:]
            line = line[:size]
        return line

    def read(self, size=-1):
        if size is None or size < 0:
            parts = [self._buf]
            self._buf = ""
            while True:
                l = self._fetch()
                if not l:
                    break
                parts.append(l)
            return "".join(parts)
        while len(self._buf) < size:
            l = self._fetch()
            if not l:
                break
            self._buf += l
        out, self._buf = self._buf[:size], self._buf[size:]
        return out

    def readlines(self, hint=-1):
        return list(self)

    def __iter__(self):
        return self

    def __next__(self):
        l = self.readline()
        if not l:
            raise StopIteration
        return l

    def isatty(self):
        return False

    def readable(self):
        return True

    def fileno(self):
        raise OSError("fileno() não suportado")


_stdin_obj = _In()


def _input(prompt=""):
    if prompt:
        sys.stdout.write(str(prompt))
    line = _stdin_obj._fetch(prompt)
    if not line:
        raise EOFError("EOF when reading a line")
    return line.rstrip("\n")


def _sleep(secs):
    end = time.monotonic() + secs
    while True:
        if _state["stop"]:
            raise KeyboardInterrupt
        left = end - time.monotonic()
        if left <= 0:
            return
        _real_sleep(min(left, 0.05))


# ------------------------------------------------------------------ controle
def provide_input(text):
    _state["stdin"].put(text)


def provide_eof():
    _state["stdin"].put(None)


def stop():
    """Pede a interrupção: seta a flag e injeta KeyboardInterrupt na thread do script."""
    _state["stop"] = True
    tid = _state["tid"]
    if tid is None:
        return False
    import ctypes
    ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_ulong(tid), ctypes.py_object(KeyboardInterrupt))
    return True


def debug_cmd(c):
    """Comando do usuário enquanto o script está pausado: 'continue' ou 'step'."""
    _dbg["cmd"].put(c)


def _vars_of(frame):
    out = []
    for k, v in list(frame.f_locals.items()):
        if k.startswith("__"):
            continue
        if isinstance(v, (types.ModuleType, types.FunctionType, types.BuiltinFunctionType, type)):
            continue
        try:
            r = repr(v)
        except BaseException:
            r = "<erro em repr>"
        if len(r) > 160:
            r = r[:157] + "..."
        out.append([k, type(v).__name__, r])
        if len(out) >= 80:
            break
    return json.dumps(out)


def _debug_pause(frame, ln):
    _flush()
    while not _dbg["cmd"].empty():
        try:
            _dbg["cmd"].get_nowait()
        except queue.Empty:
            break
    _sink.onPause(ln, _vars_of(frame))
    while True:
        if _state["stop"]:
            raise KeyboardInterrupt
        try:
            c = _dbg["cmd"].get(timeout=0.1)
            break
        except queue.Empty:
            continue
    _sink.onResume()
    _dbg["step"] = (c == "step")


def _tracer(frame, event, arg):
    if frame.f_code.co_filename != _dbg["file"]:
        return None
    if event == "line":
        if _state["stop"]:
            raise KeyboardInterrupt
        ln = frame.f_lineno
        if _dbg["step"] or ln in _dbg["bps"]:
            _dbg["step"] = False
            _debug_pause(frame, ln)
    return _tracer


class _Stoppable(ast.NodeTransformer):
    """Depois do Stop, todo `except` do script repassa a exceção (raise) em vez de engoli-la.
    Sem isso, `while True: try: input() ... except: pass` nunca terminaria."""

    def visit_ExceptHandler(self, node):
        self.generic_visit(node)
        guard = ast.If(
            test=ast.Call(func=ast.Name(id="__ci_stopping__", ctx=ast.Load()), args=[], keywords=[]),
            body=[ast.Raise(exc=None, cause=None)],
            orelse=[],
        )
        ast.copy_location(guard, node)
        node.body.insert(0, guard)
        return node


def _exit_code(e):
    c = e.code
    if c is None:
        return 0
    if isinstance(c, int):
        return c
    sys.stderr.write(str(c) + "\n")
    return 1


def _suggest(name, pool):
    low = name.lower()
    for c in pool:
        if c != name and c.lower() == low:
            return c
    m = difflib.get_close_matches(name, [c for c in pool if not c.startswith("__")], n=1, cutoff=0.75)
    return m[0] if m else ""


def _report_syntax(e, filename):
    sys.stderr.write("".join(traceback.format_exception_only(type(e), e)))
    _sink.onException(type(e).__name__, e.msg or "", e.lineno or 1, e.offset or 1, "")


def _report_exception(e, filename, g):
    tb = e.__traceback__
    while tb is not None and tb.tb_frame.f_code.co_filename == _THIS:
        tb = tb.tb_next
    line = -1
    t = tb
    while t is not None:
        if t.tb_frame.f_code.co_filename == filename:
            line = t.tb_lineno
        t = t.tb_next
    sys.stderr.write("".join(traceback.format_exception(type(e), e, tb)))
    sug = ""
    if isinstance(e, NameError) and getattr(e, "name", None):
        pool = set(g.keys()) | _BUILTIN_NAMES | set(keyword.kwlist)
        sug = _suggest(e.name, sorted(pool))
        if sug:
            sys.stderr.write("Você quis dizer: '%s'?\n" % sug)
    _sink.onException(type(e).__name__, str(e), line, 0, sug)


def run(source, filename, sink, workdir, bps="", presets=""):
    """Executa o script. Retorna o código de saída. bps = linhas com breakpoint ("3,9"); presets = respostas prontas do input()."""
    global _sink
    _sink = sink
    _state["presets"] = presets.split("\n") if presets else []
    _dbg["file"] = filename
    _dbg["bps"] = set(int(x) for x in bps.split(",") if x.strip().isdigit()) if bps else set()
    _dbg["step"] = False
    _state["tid"] = threading.get_ident()
    _state["stop"] = False
    while not _state["stdin"].empty():
        try:
            _state["stdin"].get_nowait()
        except queue.Empty:
            break
    _stdin_obj._eof = False
    _stdin_obj._buf = ""
    _repl["buf"] = []

    os.makedirs(workdir, exist_ok=True)
    os.chdir(workdir)
    if workdir not in sys.path:
        sys.path.insert(0, workdir)
    importlib.invalidate_caches()

    before_modules = set(sys.modules)
    old = (sys.stdout, sys.stderr, sys.stdin, builtins.input, time.sleep, sys.argv, sys.modules.get("__main__"))
    sys.stdout, sys.stderr, sys.stdin = _Out("out"), _Out("err"), _stdin_obj
    flush_ev = threading.Event()
    threading.Thread(target=_flusher, args=(flush_ev,), daemon=True, name="ci-flush").start()
    builtins.input = _input
    time.sleep = _sleep
    sys.argv = [filename]
    linecache.cache[filename] = (len(source), None, source.splitlines(True), filename)

    main = types.ModuleType("__main__")
    main.__file__ = filename
    sys.modules["__main__"] = main
    g = main.__dict__
    g["__ci_stopping__"] = lambda: _state["stop"]
    code = 0
    try:
        try:
            tree = _Stoppable().visit(ast.parse(source, filename))
            ast.fix_missing_locations(tree)
            compiled = compile(tree, filename, "exec")
        except SyntaxError as e:
            _report_syntax(e, filename)
            return 1
        if _dbg["bps"]:
            sys.settrace(_tracer)
        exec(compiled, g)
    except SystemExit as e:
        code = _exit_code(e)
    except KeyboardInterrupt:
        sys.stderr.write("\n[execução interrompida]\n")
        code = 130
    except BaseException as e:
        code = 1
        _report_exception(e, filename, g)
    finally:
        sys.settrace(None)
        _state["presets"] = []
        flush_ev.set()
        try:
            _flush()
        except BaseException:
            pass
        sys.stdout, sys.stderr, sys.stdin, builtins.input, time.sleep, sys.argv = old[:6]
        if old[6] is not None:
            sys.modules["__main__"] = old[6]
        # descarta módulos do workdir para que a próxima execução releia arquivos editados
        for name in set(sys.modules) - before_modules:
            f = getattr(sys.modules.get(name), "__file__", None)
            if f and str(f).startswith(workdir):
                sys.modules.pop(name, None)
        linecache.cache.pop(filename, None)
        _state["tid"] = None
        if _repl["keep"] and not isinstance(sys.exc_info()[1], SyntaxError):
            _repl["g"] = g          # o terminal herda as variáveis e funções do script
        else:
            g.clear()
        gc.collect()
    return code


# ------------------------------------------------------------------ análise estática
def _ccol(lines, lineno, byte_off):
    try:
        s = lines[lineno - 1]
        return len(s.encode("utf-8")[:byte_off].decode("utf-8", "ignore")) + 1
    except Exception:
        return byte_off + 1


def _syntax_issue(e):
    line = e.lineno or 1
    col = max(e.offset or 1, 1)
    end_line = getattr(e, "end_lineno", None) or line
    end_col = getattr(e, "end_offset", None) or (col + 1)
    return {"kind": "syntax", "type": type(e).__name__, "msg": e.msg or "invalid syntax",
            "line": line, "col": col, "end_line": end_line, "end_col": max(end_col, col), "suggest": ""}


def _undefined_names(tree, source):
    bound = set(_BUILTIN_NAMES)
    star = False
    for n in ast.walk(tree):
        if isinstance(n, ast.Name) and isinstance(n.ctx, (ast.Store, ast.Del)):
            bound.add(n.id)
        elif isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            bound.add(n.name)
        elif isinstance(n, ast.arg):
            bound.add(n.arg)
        elif isinstance(n, (ast.Import, ast.ImportFrom)):
            for a in n.names:
                if a.name == "*":
                    star = True
                else:
                    bound.add((a.asname or a.name).split(".")[0])
        elif isinstance(n, ast.ExceptHandler) and n.name:
            bound.add(n.name)
        elif isinstance(n, (ast.Global, ast.Nonlocal)):
            bound.update(n.names)
        else:
            cn = n.__class__.__name__
            if cn in ("MatchAs", "MatchStar") and getattr(n, "name", None):
                bound.add(n.name)
            elif cn == "MatchMapping" and getattr(n, "rest", None):
                bound.add(n.rest)
    if star:
        return []
    lines = source.split("\n")
    pool = sorted(bound | set(keyword.kwlist))
    out = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load) and n.id not in bound:
            el = getattr(n, "end_lineno", None) or n.lineno
            out.append({"kind": "name", "type": "NameError", "msg": "name '%s' is not defined" % n.id,
                        "line": n.lineno, "col": _ccol(lines, n.lineno, n.col_offset),
                        "end_line": el, "end_col": _ccol(lines, el, getattr(n, "end_col_offset", n.col_offset + len(n.id))),
                        "suggest": _suggest(n.id, pool)})
            if len(out) >= 60:
                break
    out.sort(key=lambda d: (d["line"], d["col"]))
    return out


def _walk_scope(node):
    stack = list(ast.iter_child_nodes(node))
    while stack:
        n = stack.pop()
        yield n
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda, ast.ClassDef)):
            continue
        stack.extend(ast.iter_child_nodes(n))


def _unused(tree, source):
    """Avisos (não são erros): imports não usados e variáveis locais atribuídas e nunca lidas."""
    lines = source.split("\n")
    out = []
    used = set()
    exported = set()
    for n in ast.walk(tree):
        if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load):
            used.add(n.id)
        elif isinstance(n, ast.Assign):
            for t in n.targets:
                if isinstance(t, ast.Name) and t.id == "__all__" and isinstance(n.value, (ast.List, ast.Tuple)):
                    for e in n.value.elts:
                        if isinstance(e, ast.Constant) and isinstance(e.value, str):
                            exported.add(e.value)
    for n in ast.walk(tree):
        if isinstance(n, (ast.Import, ast.ImportFrom)):
            if isinstance(n, ast.ImportFrom) and n.module == "__future__":
                continue
            for a in n.names:
                if a.name == "*":
                    continue
                shown = a.asname or a.name
                bound = shown.split(".")[0]
                if bound in used or bound in exported or shown in exported:
                    continue
                el = getattr(n, "end_lineno", None) or n.lineno
                out.append({"kind": "warn", "type": "UnusedImport", "msg": "'%s' imported but unused" % shown,
                            "line": n.lineno, "col": _ccol(lines, n.lineno, n.col_offset),
                            "end_line": el, "end_col": _ccol(lines, el, getattr(n, "end_col_offset", n.col_offset + 6)),
                            "suggest": "line" if len(n.names) == 1 and n.lineno == el else ""})
    for fn in ast.walk(tree):
        if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        skip = set()
        stores = {}
        dynamic = False
        for n in _walk_scope(fn):
            if isinstance(n, (ast.Global, ast.Nonlocal)):
                skip.update(n.names)
            elif isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in ("locals", "vars", "eval", "exec"):
                dynamic = True
            elif isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name):
                stores.setdefault(n.targets[0].id, n.targets[0])
            elif isinstance(n, ast.AnnAssign) and n.value is not None and isinstance(n.target, ast.Name):
                stores.setdefault(n.target.id, n.target)
        if dynamic or not stores:
            continue
        loads = set()
        for n in ast.walk(fn):
            if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load):
                loads.add(n.id)
        for name, t in stores.items():
            if name in loads or name in skip or name.startswith("_"):
                continue
            out.append({"kind": "warn", "type": "UnusedVariable", "msg": "local variable '%s' is assigned to but never used" % name,
                        "line": t.lineno, "col": _ccol(lines, t.lineno, t.col_offset),
                        "end_line": t.lineno, "end_col": _ccol(lines, t.lineno, t.col_offset + len(name)), "suggest": ""})
    return out


def check(source, filename="<editor>"):
    """Retorna JSON com os problemas: erro de sintaxe (CPython real) ou nomes não definidos."""
    try:
        compile(source, filename, "exec")
    except SyntaxError as e:
        return json.dumps([_syntax_issue(e)])
    except (ValueError, RecursionError, MemoryError, OverflowError):
        return "[]"
    try:
        tree = ast.parse(source, filename)
        issues = _undefined_names(tree, source)
        try:
            issues = issues + _unused(tree, source)
        except Exception:
            pass
        return json.dumps(issues)
    except Exception:
        return "[]"


# ------------------------------------------------------------------ auto-completar (membros depois do ponto)
_BTYPES = {"str": str, "int": int, "float": float, "bool": bool, "list": list, "dict": dict, "set": set,
           "tuple": tuple, "bytes": bytes, "frozenset": frozenset, "range": range, "complex": complex}
_CALL_RET = dict(_BTYPES, input=str, len=int, sorted=list, repr=str, chr=str, ord=int, format=str,
                 open=io.TextIOWrapper, reversed=reversed, enumerate=enumerate, zip=zip, map=map, filter=filter)
_STR_RET = {m: str for m in ("lower", "upper", "strip", "lstrip", "rstrip", "title", "capitalize", "replace", "format",
                             "join", "center", "ljust", "rjust", "zfill", "casefold", "swapcase", "removeprefix", "removesuffix")}
_STR_RET.update({"split": list, "rsplit": list, "splitlines": list, "partition": tuple,
                 "find": int, "count": int, "index": int, "encode": bytes})
_NO_IMPORT = {"antigravity", "this", "idlelib", "turtle", "tkinter", "turtledemo"}

_RE_IMPORT = re.compile(r"^\s*import\s+(.+?)\s*(?:#.*)?$")
_RE_FROM = re.compile(r"^\s*from\s+([\w\.]+)\s+import\s+(.+?)\s*(?:#.*)?$")
_RE_ASSIGN = re.compile(r"^\s*([A-Za-z_]\w*)\s*(?::[^=]+)?=(?!=)\s*(.+?)\s*$")
_RE_WITH = re.compile(r"^\s*(?:async\s+)?with\s+(.+?)\s+as\s+([A-Za-z_]\w*)\s*:")
_RE_FOR = re.compile(r"^\s*for\s+([A-Za-z_]\w*)\s+in\s+(.+?)\s*:\s*(?:#.*)?$")
_RE_CLASS = re.compile(r"^(\s*)class\s+([A-Za-z_]\w*)\s*(?:\(([^)]*)\))?\s*:")
_RE_DEF = re.compile(r"^(\s*)(?:async\s+)?def\s+([A-Za-z_]\w*)\s*\(([^)]*)\)")
_RE_SELF = re.compile(r"\bself\.([A-Za-z_]\w*)\s*(?::[^=]+)?=(?!=)\s*(.+?)\s*$")


def _import_safe(name):
    top = name.split(".")[0]
    if top in _NO_IMPORT:
        return None
    if top not in sys.modules and top not in getattr(sys, "stdlib_module_names", ()) and top != "requests":
        return None
    try:
        return importlib.import_module(name)
    except BaseException:
        return None


def _parse_expr(s):
    try:
        return ast.parse(s.strip(), mode="eval").body
    except SyntaxError:
        if "#" in s:
            try:
                return ast.parse(s[:s.index("#")].strip(), mode="eval").body
            except SyntaxError:
                return None
        return None


def _match_open(s, pos):
    close = s[pos]
    opener = {")": "(", "]": "[", "}": "{"}[close]
    depth = 0
    i = pos
    while i >= 0:
        c = s[i]
        if c == close:
            depth += 1
        elif c == opener:
            depth -= 1
            if depth == 0:
                return i
        i -= 1
    return -1


def _tail_expr(s):
    """Expressão que termina em s (antes do ponto): nomes, chamadas, índices e literais."""
    s = s.rstrip()
    i = len(s)
    while i > 0:
        c = s[i - 1]
        if c in ")]}":
            j = _match_open(s, i - 1)
            if j < 0:
                break
            i = j
            continue
        if c.isalnum() or c == "_" or c == ".":
            i -= 1
            continue
        if c in "\"'":
            j = s.rfind(c, 0, i - 1)
            if j < 0:
                break
            i = j
            while i > 0 and s[i - 1] in "rRbBfFuU":
                i -= 1
            break
        break
    return s[i:]


def _has_params(v, drop_first):
    try:
        ps = list(inspect.signature(v).parameters.values())
        if drop_first and ps:
            ps = ps[1:]
        return len(ps) > 0
    except (ValueError, TypeError):
        return True


class _Ctx:
    """Contexto de completar: lê o próprio texto (mesmo incompleto) sem executar o código do usuário."""

    def __init__(self, lines, line):
        self.lines = lines
        self.line = line              # 1-based; a linha atual é ignorada
        self.mods = {}                # alias -> ("mod", nome) | ("from", base, nome)
        self.assigns = {}             # nome -> [(linha, nó | ("iter", nó))]
        self.classes = {}             # nome -> {"methods": {}, "attrs": {}, "bases": []}
        self._scan()

    def _scan(self):
        lines = self.lines
        for i, ln in enumerate(lines):
            if i + 1 == self.line:
                continue
            m = _RE_IMPORT.match(ln)
            if m:
                for part in m.group(1).split(","):
                    part = part.strip()
                    if not part:
                        continue
                    if " as " in part:
                        name, alias = [x.strip() for x in part.split(" as ", 1)]
                        self.mods[alias] = ("mod", name)
                    else:
                        top = part.split(".")[0]
                        self.mods[top] = ("mod", top)
                continue
            m = _RE_FROM.match(ln)
            if m:
                base = m.group(1)
                for part in m.group(2).replace("(", "").replace(")", "").split(","):
                    part = part.strip()
                    if not part or part == "*":
                        continue
                    if " as " in part:
                        name, alias = [x.strip() for x in part.split(" as ", 1)]
                    else:
                        name = alias = part
                    self.mods[alias] = ("from", base, name)
                continue
            m = _RE_WITH.match(ln)
            if m:
                node = _parse_expr(m.group(1))
                if node is not None:
                    self.assigns.setdefault(m.group(2), []).append((i + 1, node))
                continue
            m = _RE_FOR.match(ln)
            if m:
                node = _parse_expr(m.group(2))
                if node is not None:
                    self.assigns.setdefault(m.group(1), []).append((i + 1, ("iter", node)))
                continue
            m = _RE_ASSIGN.match(ln)
            if m:
                node = _parse_expr(m.group(2))
                if node is not None:
                    self.assigns.setdefault(m.group(1), []).append((i + 1, node))
        # classes
        n = len(lines)
        for i, ln in enumerate(lines):
            m = _RE_CLASS.match(ln)
            if not m:
                continue
            cind = len(m.group(1))
            name = m.group(2)
            bases = [b.strip() for b in (m.group(3) or "").split(",") if b.strip()]
            info = {"methods": {}, "attrs": {}, "bases": bases}
            body_ind = None
            j = i + 1
            while j < n:
                lj = lines[j]
                if lj.strip():
                    ind = len(lj) - len(lj.lstrip())
                    if ind <= cind:
                        break
                    if body_ind is None:
                        body_ind = ind
                    md = _RE_DEF.match(lj)
                    if md and ind == body_ind:
                        params = [p.strip() for p in md.group(3).split(",") if p.strip()]
                        if params and params[0].lstrip("*").split(":")[0].split("=")[0].strip() in ("self", "cls"):
                            params = params[1:]
                        info["methods"][md.group(2)] = len(params) > 0
                    ms = _RE_SELF.search(lj)
                    if ms:
                        info["attrs"][ms.group(1)] = _parse_expr(ms.group(2))
                    elif ind == body_ind:
                        ma = _RE_ASSIGN.match(lj)
                        if ma:
                            info["attrs"][ma.group(1)] = _parse_expr(ma.group(2))
                j += 1
            self.classes[name] = info

    def _enclosing(self):
        lines = self.lines
        i = self.line - 1
        cur = lines[i]
        ind = len(cur) - len(cur.lstrip())
        if not cur.strip():
            k = i - 1
            while k >= 0 and not lines[k].strip():
                k -= 1
            ind = (len(lines[k]) - len(lines[k].lstrip()) + 1) if k >= 0 else 0
        defs, cls = [], None
        j = i - 1
        while j >= 0 and ind > 0:
            ln = lines[j]
            if ln.strip():
                ji = len(ln) - len(ln.lstrip())
                if ji < ind:
                    if _RE_DEF.match(ln):
                        defs.append(j)
                    else:
                        mc = _RE_CLASS.match(ln)
                        if mc and cls is None:
                            cls = mc.group(2)
                    ind = ji
            j -= 1
        return defs, cls

    def _params(self, defs):
        out = {}
        for j in defs:
            md = _RE_DEF.match(self.lines[j])
            if not md:
                continue
            try:
                fn = ast.parse("def _f(%s): pass" % md.group(3)).body[0]
            except SyntaxError:
                continue
            a = fn.args
            pos = list(a.posonlyargs) + list(a.args)
            defaults = [None] * (len(pos) - len(a.defaults)) + list(a.defaults)
            for arg, dflt in zip(pos, defaults):
                if arg.arg in out or arg.arg in ("self", "cls"):
                    continue
                spec = None
                ann = arg.annotation
                if isinstance(ann, ast.Subscript):
                    ann = ann.value
                if isinstance(ann, ast.Name) and ann.id in _BTYPES:
                    spec = ("type", _BTYPES[ann.id])
                elif dflt is not None:
                    spec = self._infer(dflt, 3)
                out[arg.arg] = spec
        return out

    # ---- inferência
    def _name(self, name, depth):
        defs, cls = self._enclosing()
        if name == "self" and cls:
            return ("inst", cls)
        params = self._params(defs)
        if name in params and params[name] is not None:
            return params[name]
        lst = self.assigns.get(name)
        if lst:
            before = [x for x in lst if x[0] < self.line]
            pick = (before or lst)[-1][1]
            if isinstance(pick, tuple):
                it = self._infer(pick[1], depth + 1)
                if it and it[0] == "type":
                    if it[1] is str:
                        return ("type", str)
                    if it[1] is range:
                        return ("type", int)
                return None
            return self._infer(pick, depth + 1)
        if name in self.classes:
            return ("class", name)
        if name in self.mods:
            return self._module(name)
        if name in _BTYPES:
            return ("obj", _BTYPES[name])
        return None

    def _module(self, alias):
        spec = self.mods[alias]
        if spec[0] == "mod":
            m = _import_safe(spec[1])
            return ("module", m) if m is not None else None
        base, attr = spec[1], spec[2]
        mod = _import_safe(base)
        if mod is None:
            return None
        v = getattr(mod, attr, None)
        if v is None:
            sub = _import_safe(base + "." + attr)
            return ("module", sub) if sub is not None else None
        return ("module", v) if inspect.ismodule(v) else ("obj", v)

    def _attr(self, base, attr, depth):
        if base is None:
            return None
        k = base[0]
        if k == "module":
            v = getattr(base[1], attr, None)
            if v is None:
                sub = _import_safe(getattr(base[1], "__name__", "") + "." + attr)
                return ("module", sub) if sub is not None else None
            return ("module", v) if inspect.ismodule(v) else ("obj", v)
        if k == "obj":
            v = getattr(base[1], attr, None)
            return ("obj", v) if v is not None else None
        if k in ("inst", "class"):
            info = self.classes.get(base[1])
            seen = set()
            while info is not None and id(info) not in seen:
                seen.add(id(info))
                if attr in info["attrs"] and info["attrs"][attr] is not None:
                    return self._infer(info["attrs"][attr], depth + 1)
                nxt = None
                for b in info["bases"]:
                    if b in self.classes:
                        nxt = self.classes[b]
                        break
                info = nxt
        return None

    def _infer(self, node, depth=0):
        if node is None or depth > 6:
            return None
        t = type(node).__name__
        if t == "Constant":
            v = node.value
            return ("type", type(v)) if v is not None and v is not Ellipsis else None
        if t == "JoinedStr":
            return ("type", str)
        if t in ("List", "ListComp"):
            return ("type", list)
        if t in ("Dict", "DictComp"):
            return ("type", dict)
        if t in ("Set", "SetComp"):
            return ("type", set)
        if t == "Tuple":
            return ("type", tuple)
        if t == "BinOp":
            l = self._infer(node.left, depth + 1)
            if l and l[0] == "type" and l[1] in (str, list, tuple, int, float):
                return l
            return None
        if t == "Name":
            return self._name(node.id, depth)
        if t == "Attribute":
            return self._attr(self._infer(node.value, depth + 1), node.attr, depth)
        if t == "Subscript":
            b = self._infer(node.value, depth + 1)
            return b if b == ("type", str) else None
        if t == "Call":
            f = node.func
            if isinstance(f, ast.Name):
                nm = f.id
                if nm in self.classes:
                    return ("inst", nm)
                obj = self._name(nm, depth + 1)
                if obj and obj[0] == "obj" and inspect.isclass(obj[1]):
                    return ("type", obj[1])
                if nm in _CALL_RET:
                    return ("type", _CALL_RET[nm])
                return None
            if isinstance(f, ast.Attribute):
                base = self._infer(f.value, depth + 1)
                if base and base[0] == "type":
                    if base[1] is str and f.attr in _STR_RET:
                        return ("type", _STR_RET[f.attr])
                    if base[1] in (list, dict, set) and f.attr == "copy":
                        return base
                    return None
                ob = self._attr(base, f.attr, depth + 1)
                if ob and ob[0] == "obj" and inspect.isclass(ob[1]):
                    return ("type", ob[1])
            return None
        return None

    # ---- membros
    def _collect(self, obj, out, via_type):
        for n in dir(obj):
            if n.startswith("_"):
                continue
            try:
                v = getattr(obj, n)
            except BaseException:
                continue
            if inspect.ismodule(v):
                out[n] = ("m", False)
            elif inspect.isclass(v):
                out[n] = ("c", False)
            elif callable(v):
                out[n] = ("f", _has_params(v, via_type))
            else:
                out[n] = ("v", False)

    def _user_members(self, name, out, seen):
        info = self.classes.get(name)
        if info is None or name in seen:
            return
        seen.add(name)
        for m, hp in info["methods"].items():
            if not m.startswith("_"):
                out[m] = ("f", hp)
        for a in info["attrs"]:
            if not a.startswith("_") and a not in out:
                out[a] = ("v", False)
        for b in info["bases"]:
            if b in self.classes:
                self._user_members(b, out, seen)
            elif b in _BTYPES:
                self._collect(_BTYPES[b], out, True)
            else:
                bo = getattr(builtins, b, None)
                if inspect.isclass(bo):
                    self._collect(bo, out, True)

    def members(self, spec):
        out = {}
        k, obj = spec[0], spec[1]
        if k == "module":
            self._collect(obj, out, False)
        elif k == "obj":
            self._collect(obj, out, inspect.isclass(obj))
        elif k == "type":
            self._collect(obj, out, True)
        elif k in ("inst", "class"):
            self._user_members(obj, out, set())
        return out


def complete(source, line, col):
    """Membros depois de 'objeto.': JSON [[nome, tipo, tem_parametros], ...] (tipo: f função, v valor, c classe, m módulo)."""
    try:
        lines = source.split("\n")
        if not (1 <= line <= len(lines)):
            return "[]"
        before = lines[line - 1][:col]
        if not before.endswith("."):
            return "[]"
        expr = _tail_expr(before[:-1])
        node = _parse_expr(expr) if expr else None
        if node is None:
            return "[]"
        ctx = _Ctx(lines, line)
        spec = ctx._infer(node)
        if spec is None:
            return "[]"
        mem = ctx.members(spec)
        return json.dumps(sorted([[n, k, hp] for n, (k, hp) in mem.items()], key=lambda x: (x[0][0].isupper(), x[0].lower()))[:400])
    except BaseException:
        return "[]"


# ------------------------------------------------------------------ terminal Python (REPL)
_repl = {"g": None, "buf": [], "keep": False}


def repl_reset():
    _repl["g"] = {"__name__": "__main__", "__doc__": None, "__builtins__": builtins, "__ci_stopping__": lambda: _state["stop"]}
    _repl["buf"] = []


def repl_keep(on):
    """Com o terminal ligado, as variáveis do último script ficam disponíveis nele (como 'python -i')."""
    _repl["keep"] = bool(on)


def repl_run(line, sink, workdir):
    """Executa uma linha do terminal no namespace persistente. Retorna 'more' se o bloco ainda está incompleto."""
    global _sink
    _sink = sink
    if _repl["g"] is None:
        repl_reset()
    buf = _repl["buf"]
    if not line.strip() and not buf:
        return "done"
    buf.append(line)
    src = "\n".join(buf)
    old_sink_err = None
    try:
        code = codeop.compile_command(src, "<console>", "single")
    except (SyntaxError, OverflowError, ValueError) as e:
        buf.clear()
        _state["stop"] = False
        _emit("err", "".join(traceback.format_exception_only(type(e), e)))
        _flush()
        return "done"
    if code is None:
        return "more"
    buf.clear()

    _state["tid"] = threading.get_ident()
    _state["stop"] = False
    _state["presets"] = []
    while not _state["stdin"].empty():
        try:
            _state["stdin"].get_nowait()
        except queue.Empty:
            break
    _stdin_obj._eof = False
    _stdin_obj._buf = ""
    os.makedirs(workdir, exist_ok=True)
    os.chdir(workdir)
    if workdir not in sys.path:
        sys.path.insert(0, workdir)
    old = (sys.stdout, sys.stderr, sys.stdin, builtins.input, time.sleep)
    sys.stdout, sys.stderr, sys.stdin = _Out("out"), _Out("err"), _stdin_obj
    flush_ev = threading.Event()
    threading.Thread(target=_flusher, args=(flush_ev,), daemon=True, name="ci-flush").start()
    builtins.input = _input
    time.sleep = _sleep
    try:
        exec(code, _repl["g"])
    except SystemExit:
        sys.stderr.write("[exit() ignorado no terminal]\n")
    except KeyboardInterrupt:
        sys.stderr.write("\n[interrompido]\n")
    except BaseException as e:
        tb = e.__traceback__
        while tb is not None and tb.tb_frame.f_code.co_filename == _THIS:
            tb = tb.tb_next
        sys.stderr.write("".join(traceback.format_exception(type(e), e, tb)))
    finally:
        flush_ev.set()
        try:
            _flush()
        except BaseException:
            pass
        sys.stdout, sys.stderr, sys.stdin, builtins.input, time.sleep = old
        _state["tid"] = None
    return "done"



_THIS = run.__code__.co_filename
