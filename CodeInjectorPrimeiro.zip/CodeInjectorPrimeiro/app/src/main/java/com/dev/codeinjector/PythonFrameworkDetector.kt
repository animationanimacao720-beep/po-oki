package com.dev.codeinjector

/** Detecção conservadora de imports explícitos no arquivo Python principal. */
object PythonFrameworkDetector {
    fun detect(source: String): String? {
        val importPattern = Regex(
            "^[ \\t]*(?:from[ \\t]+(kivy|pygame)(?:\\.[A-Za-z_][A-Za-z0-9_.]*)?[ \\t]+import\\b|import[ \\t]+([^\\n#;]+))",
            RegexOption.MULTILINE
        )
        for (match in importPattern.findAll(source)) {
            val fromModule = match.groupValues.getOrNull(1).orEmpty()
            if (fromModule == "kivy" || fromModule == "pygame") return fromModule
            val names = match.groupValues.getOrNull(2).orEmpty()
            val modules = names.split(',').map { it.trim().substringBefore(" as ").trim() }
            when {
                modules.any { it == "kivy" || it.startsWith("kivy.") } -> return "kivy"
                modules.any { it == "pygame" || it.startsWith("pygame.") } -> return "pygame"
            }
        }
        return null
    }
}
