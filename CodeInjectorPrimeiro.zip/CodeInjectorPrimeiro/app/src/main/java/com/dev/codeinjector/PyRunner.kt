package com.dev.codeinjector

import android.content.Context
import android.os.Process
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.io.File
import java.util.concurrent.Executors
import java.util.UUID
import kotlin.concurrent.thread

enum class StreamKind { OUT, ERR, IN, SYS }
data class ConsoleChunk(val kind: StreamKind, val text: String)
enum class RunState { IDLE, STARTING, RUNNING, WAITING_INPUT, STOPPING }

/** Erro de execução (traceback) do último script. [sourceHash] liga o erro ao texto que foi executado. */
data class PyRuntimeError(
    val type: String, val message: String, val line: Int, val col: Int,
    val suggestion: String, val fileName: String, val sourceHash: Int
)

/** Sugestão de membro vinda do Python: tipo "f" função, "v" valor, "c" classe, "m" módulo. */
data class MemberSug(val name: String, val kind: String, val hasParams: Boolean)

/** Script pausado num breakpoint/passo: linha (1-based) e variáveis (nome, tipo, valor). */
data class PyPause(val line: Int, val fileName: String, val vars: List<Triple<String, String, String>>)

/** Interface chamada pelo Python (ci_runner.py). Os nomes dos métodos precisam bater com o módulo. */
interface PySink {
    fun onPause(line: Int, vars: String)
    fun onResume()
    fun write(stream: String, text: String)
    fun onInputRequested(prompt: String)
    fun onInputConsumed()
    fun onException(type: String, message: String, line: Int, col: Int, suggestion: String)
}

/**
 * CPython nativo (Chaquopy). Executa um script por vez numa thread dedicada, com:
 *  - stdout/stderr em tempo real (chunks agrupados a cada ~30 ms, limite de memória),
 *  - input()/sys.stdin interativos ([sendInput] / [sendEof]),
 *  - parada imediata ([stop]) e, em último caso, [forceKill].
 */
object PyRunner : PySink {
    private const val MODULE = "ci_runner"
    private const val MAX_CHARS = 60_000

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val ctl = Executors.newSingleThreadExecutor { r -> Thread(r, "py-ctl").apply { isDaemon = true } }.asCoroutineDispatcher()
    private val outCh = Channel<ConsoleChunk>(Channel.UNLIMITED)

    private val _chunks = MutableStateFlow<List<ConsoleChunk>>(emptyList())
    val chunks: StateFlow<List<ConsoleChunk>> = _chunks.asStateFlow()
    private val _state = MutableStateFlow(RunState.IDLE)
    val state: StateFlow<RunState> = _state.asStateFlow()
    private val _prompt = MutableStateFlow<String?>(null)
    /** Não nulo enquanto o script espera por input() (contém o texto do prompt). */
    val prompt: StateFlow<String?> = _prompt.asStateFlow()
    private val _error = MutableStateFlow<PyRuntimeError?>(null)
    val error: StateFlow<PyRuntimeError?> = _error.asStateFlow()
    private val _pause = MutableStateFlow<PyPause?>(null)
    /** Não nulo enquanto o script está parado num breakpoint. */
    val pause: StateFlow<PyPause?> = _pause.asStateFlow()
    private val _repl = MutableStateFlow(false)
    /** Terminal Python (REPL) ligado no console. */
    val replMode: StateFlow<Boolean> = _repl.asStateFlow()
    private val _replMore = MutableStateFlow(false)
    /** true quando o terminal espera continuação de um bloco (prompt "..."). */
    val replMore: StateFlow<Boolean> = _replMore.asStateFlow()
    private val _stuck = MutableStateFlow(false)
    /** true quando o Stop não conseguiu encerrar o script (ex.: preso em código nativo). */
    val stuck: StateFlow<Boolean> = _stuck.asStateFlow()

    @Volatile private var runFile = ""
    @Volatile private var runHash = 0
    @Volatile private var stopRequested = false
    @Volatile private var externalRunId: String? = null
    @Volatile private var externalAppContext: Context? = null
    private var written = emptySet<String>()

    init {
        scope.launch {
            for (first in outCh) {
                val batch = ArrayList<ConsoleChunk>()
                batch += first
                delay(60)
                while (true) batch += (outCh.tryReceive().getOrNull() ?: break)
                _chunks.update { merge(it, batch) }
            }
        }
    }

    private fun merge(old: List<ConsoleChunk>, add: List<ConsoleChunk>): List<ConsoleChunk> {
        // junta chunks consecutivos do mesmo tipo com StringBuilder (evita concatenação quadrática)
        val groups = ArrayList<ConsoleChunk>()
        var kind: StreamKind? = null
        var sb = StringBuilder()
        for (c in add) {
            if (c.kind != kind) {
                if (kind != null) groups += ConsoleChunk(kind, sb.toString())
                kind = c.kind
                sb = StringBuilder()
            }
            sb.append(c.text)
        }
        if (kind != null) groups += ConsoleChunk(kind, sb.toString())
        val out = ArrayList<ConsoleChunk>(old.size + groups.size)
        out.addAll(old)
        for (g in groups) {
            val last = out.lastOrNull()
            if (last != null && last.kind == g.kind) out[out.lastIndex] = last.copy(text = last.text + g.text) else out += g
        }
        var total = out.sumOf { it.text.length }
        while (total > MAX_CHARS && out.size > 1) total -= out.removeAt(0).text.length
        if (total > MAX_CHARS) out[0] = out[0].copy(text = out[0].text.takeLast(MAX_CHARS))
        return out
    }

    fun clearConsole() { _chunks.value = emptyList() }

    private fun emit(kind: StreamKind, text: String) { outCh.trySend(ConsoleChunk(kind, text)) }

    // ---------------------------------------------------------------- PySink (chamado pelo Python)
    override fun write(stream: String, text: String) =
        emit(when (stream) { "err" -> StreamKind.ERR; "in" -> StreamKind.IN; else -> StreamKind.OUT }, text)

    override fun onPause(line: Int, vars: String) {
        val list = runCatching {
            val a = JSONArray(vars)
            (0 until a.length()).map { val r = a.getJSONArray(it); Triple(r.getString(0), r.getString(1), r.getString(2)) }
        }.getOrDefault(emptyList())
        _pause.value = PyPause(line, runFile, list)
    }

    override fun onResume() { _pause.value = null }

    fun debugContinue() { _pause.value = null; scope.launch(ctl) { runCatching { module().callAttr("debug_cmd", "continue") } } }
    fun debugStep() { _pause.value = null; scope.launch(ctl) { runCatching { module().callAttr("debug_cmd", "step") } } }

    override fun onInputRequested(prompt: String) {
        _prompt.value = prompt
        if (_state.value == RunState.RUNNING) _state.value = RunState.WAITING_INPUT
    }

    override fun onInputConsumed() {
        _prompt.value = null
        if (_state.value == RunState.WAITING_INPUT) _state.value = RunState.RUNNING
    }

    override fun onException(type: String, message: String, line: Int, col: Int, suggestion: String) {
        _error.value = PyRuntimeError(type, message, line, col, suggestion, runFile, runHash)
    }

    // ---------------------------------------------------------------- ciclo de vida
    @Synchronized
    fun ensureStarted(ctx: Context) {
        if (!Python.isStarted()) Python.start(AndroidPlatform(ctx.applicationContext))
    }

    /** Inicializa o interpretador em segundo plano (chame ao abrir o app). */
    fun warmUp(ctx: Context) { scope.launch { runCatching { ensureStarted(ctx) } } }

    fun workDir(ctx: Context) = File(ctx.filesDir, "py_workspace").also { it.mkdirs() }

    private fun module() = Python.getInstance().getModule(MODULE)

    /**
     * Executa [source]. [siblings] (nome -> texto) são gravados no diretório de trabalho para que
     * `import outro_arquivo` funcione entre as abas abertas.
     */
    fun run(
        ctx: Context, source: String, fileName: String, siblings: Map<String, String> = emptyMap(),
        breakpoints: List<Int> = emptyList(), presets: String = ""
    ) {
        // Classifica pelo arquivo executado, não por qualquer aba aberta: uma aba Kivy não deve
        // fazer um script Python comum ser enviado ao Termux por acidente.
        val graphicFramework = TermuxX11Runner.detectFramework(source)
        if (graphicFramework != null) {
            runThroughTermuxX11(ctx, source, fileName, siblings, graphicFramework)
            return
        }
        if (_state.value != RunState.IDLE) return
        _state.value = RunState.STARTING
        stopRequested = false
        _chunks.value = emptyList(); _error.value = null; _prompt.value = null; _stuck.value = false; _pause.value = null; _replMore.value = false
        runFile = fileName; runHash = source.hashCode()
        val app = ctx.applicationContext
        thread(name = "py-run", isDaemon = true) {
            var code = -1
            val t0 = System.nanoTime()
            try {
                ensureStarted(app)
                val work = workDir(app)
                val names = HashSet<String>()
                siblings.forEach { (n, t) ->
                    if (n.endsWith(".py") && '/' !in n && n != "$MODULE.py") {
                        runCatching { File(work, n).writeText(t); names += n }
                    }
                }
                (written - names).forEach { File(work, it).delete() }
                written = names
                if (!stopRequested) {
                    _state.value = RunState.RUNNING
                    code = module().callAttr("run", source, fileName, this@PyRunner, work.absolutePath, breakpoints.joinToString(","), presets).toInt()
                }
            } catch (e: Throwable) {
                emit(StreamKind.ERR, "[erro interno] ${e.message}\n")
            } finally {
                _prompt.value = null; _pause.value = null
                val secs = (System.nanoTime() - t0) / 1_000_000_000.0
                val dur = if (secs < 1) "${(secs * 1000).toInt()} ms" else String.format(java.util.Locale.US, "%.2f s", secs)
                emit(StreamKind.SYS, if (code == 130 || stopRequested) "\n[processo interrompido após $dur]\n" else "\n[processo finalizado com código $code em $dur]\n")
                _state.value = RunState.IDLE
                _stuck.value = false
            }
        }
    }

    /** Encaminha Kivy/Pygame ao Python do Termux, mantendo o console ciente do processo externo. */
    private fun runThroughTermuxX11(
        ctx: Context, source: String, fileName: String, siblings: Map<String, String>, framework: String
    ) {
        if (_state.value != RunState.IDLE) return
        _state.value = RunState.STARTING
        _chunks.value = emptyList(); _error.value = null; _prompt.value = null
        _stuck.value = false; _pause.value = null; _replMore.value = false
        stopRequested = false
        runFile = fileName; runHash = source.hashCode()
        val app = ctx.applicationContext
        val runId = UUID.randomUUID().toString().replace("-", "")
        externalRunId = runId
        externalAppContext = app
        emit(StreamKind.SYS, "[CodeInjector] Import de ${if (framework == "kivy") "Kivy" else "Pygame"} detectado. Encaminhando o script para Termux:X11…\n")
        thread(name = "termux-x11-launch", isDaemon = true) {
            val result = TermuxX11Runner.launch(app, source, fileName, siblings, framework, runId)
            result.onSuccess { launched ->
                if (externalRunId == launched.runId) {
                    // Se o usuário tocou em Parar enquanto o Intent estava sendo enviado,
                    // não sobrescreva STOPPING com RUNNING: espere o shell criar .pid e
                    // reenvie o sinal para cobrir a corrida de inicialização.
                    if (stopRequested || _state.value == RunState.STOPPING) {
                        emit(StreamKind.SYS, "[CodeInjector] Cancelando a inicialização do script gráfico…\n")
                        Thread.sleep(500)
                        TermuxX11Runner.stop(app, launched.runId, force = false)
                    } else {
                        _state.value = RunState.RUNNING
                        emit(StreamKind.SYS, "[CodeInjector] ${launched.framework} está executando no Termux:X11. Feche a janela do programa para concluir.\n")
                    }
                }
            }.onFailure { error ->
                if (externalRunId == runId) {
                    externalRunId = null
                    externalAppContext = null
                    emit(StreamKind.ERR, "[Termux:X11] ${error.message ?: error.javaClass.simpleName}\n")
                    emit(StreamKind.SYS, "[o script não foi iniciado]\n")
                    _state.value = RunState.IDLE
                    _stuck.value = false
                }
            }
        }
    }

    /** Chamado pelo receiver quando a sessão Termux conclui o script gráfico. */
    @Synchronized
    fun onExternalCommandFinished(runId: String, exitCode: Int, stdout: String, stderr: String, error: String) {
        if (externalRunId != runId) return
        if (stdout.isNotBlank()) emit(StreamKind.OUT, stdout.takeLast(8_000).trimEnd() + "\n")
        if (stderr.isNotBlank()) emit(StreamKind.ERR, stderr.takeLast(8_000).trimEnd() + "\n")
        if (error.isNotBlank()) emit(StreamKind.ERR, "[Termux] ${error.takeLast(4_000)}\n")
        emit(StreamKind.SYS, if (exitCode == 0) "\n[script gráfico finalizado no Termux:X11]\n" else "\n[script gráfico encerrado com código $exitCode no Termux:X11]\n")
        externalRunId = null
        externalAppContext = null
        _prompt.value = null
        _state.value = RunState.IDLE
        _stuck.value = false
    }

    /** Envia uma linha para o input() em espera (ecoa no console). */
    fun sendInput(line: String) {
        if (_prompt.value == null) return
        emit(StreamKind.IN, line + "\n")
        _prompt.value = null
        if (_state.value == RunState.WAITING_INPUT) _state.value = RunState.RUNNING
        scope.launch(ctl) { runCatching { module().callAttr("provide_input", line) } }
    }

    /** Equivale a Ctrl+D: encerra a entrada padrão. */
    fun sendEof() {
        if (_prompt.value == null) return
        emit(StreamKind.IN, "^D\n")
        _prompt.value = null
        scope.launch(ctl) { runCatching { module().callAttr("provide_eof") } }
    }

    /** Interrompe o script: reenvia KeyboardInterrupt a cada 250 ms por até 3 s (o código do usuário pode capturá-lo). */
    fun stop() {
        val externalId = externalRunId
        if (externalId != null) {
            if (_state.value == RunState.IDLE) return
            if (_state.value == RunState.STOPPING && !_stuck.value) return
            val app = externalAppContext ?: return
            _stuck.value = false
            _state.value = RunState.STOPPING
            TermuxX11Runner.stop(app, externalId, force = false)
            scope.launch {
                delay(1800)
                if (externalRunId == externalId && _state.value != RunState.IDLE) {
                    emit(StreamKind.SYS, "\n[o processo gráfico ainda está ativo; toque em Parar novamente ou use Forçar encerramento]\n")
                    _stuck.value = true
                }
            }
            return
        }
        val s = _state.value
        if (s == RunState.IDLE) return
        // se o Stop anterior não funcionou (stuck), tocar de novo tenta outra rodada
        if (s == RunState.STOPPING && !_stuck.value) return
        stopRequested = true
        _pause.value = null
        _stuck.value = false
        _state.value = RunState.STOPPING
        if (s == RunState.STARTING) return
        scope.launch(ctl) {
            repeat(12) {
                if (_state.value == RunState.IDLE) return@launch
                runCatching { module().callAttr("stop") }
                delay(250)
            }
            if (_state.value != RunState.IDLE) {
                emit(StreamKind.SYS, "\n[o script não respondeu ao Stop — use \"Forçar encerramento\"]\n")
                _stuck.value = true
            }
        }
    }

    /** Encerra só o script Termux quando ele é externo; senão encerra este processo como último recurso. */
    fun forceKill() {
        val externalId = externalRunId
        if (externalId != null) {
            externalAppContext?.let { TermuxX11Runner.stop(it, externalId, force = true) }
            externalRunId = null
            externalAppContext = null
            _state.value = RunState.IDLE
            _stuck.value = false
            emit(StreamKind.SYS, "[enviado SIGKILL para o processo gráfico no Termux]\n")
        } else {
            Process.killProcess(Process.myPid())
        }
    }

    // ---------------------------------------------------------------- terminal Python (REPL)
    fun setRepl(on: Boolean) {
        _repl.value = on; _replMore.value = false
        if (on && _chunks.value.isEmpty()) emit(StreamKind.SYS, "Terminal Python ativo. Digite comandos abaixo; blocos (def, for…) terminam com uma linha em branco.\n")
        scope.launch(ctl) { runCatching { module().callAttr("repl_keep", on) } }
    }

    fun resetRepl() {
        _replMore.value = false
        emit(StreamKind.SYS, "[terminal reiniciado]\n")
        scope.launch(ctl) { runCatching { module().callAttr("repl_reset") } }
    }

    /** Executa uma linha do terminal no namespace persistente. */
    fun replSubmit(ctx: Context, line: String) {
        if (_state.value != RunState.IDLE) return
        _state.value = RunState.STARTING
        stopRequested = false; _prompt.value = null; _stuck.value = false; _pause.value = null
        runFile = "<console>"
        emit(StreamKind.IN, (if (_replMore.value) "... " else ">>> ") + line + "\n")
        val app = ctx.applicationContext
        thread(name = "py-repl", isDaemon = true) {
            try {
                ensureStarted(app)
                val work = workDir(app)
                if (!stopRequested) {
                    _state.value = RunState.RUNNING
                    val r = module().callAttr("repl_run", line, this@PyRunner, work.absolutePath).toString()
                    _replMore.value = (r == "more")
                }
            } catch (e: Throwable) {
                emit(StreamKind.ERR, "[erro interno] ${e.message}\n")
            } finally {
                if (stopRequested) _replMore.value = false
                _prompt.value = null; _pause.value = null
                _state.value = RunState.IDLE
                _stuck.value = false
            }
        }
    }

    /** Membros depois de "objeto." (col = posição logo após o ponto, 0-based). Null se o Python ainda não iniciou. */
    fun complete(source: String, line: Int, col: Int): List<MemberSug>? = runCatching {
        if (!Python.isStarted()) return null
        val arr = JSONArray(module().callAttr("complete", source, line, col).toString())
        (0 until arr.length()).map { val a = arr.getJSONArray(it); MemberSug(a.getString(0), a.getString(1), a.getBoolean(2)) }
    }.getOrNull()

    // ---------------------------------------------------------------- análise
    /** Verificação com o parser real do CPython. Retorna null se o interpretador ainda não iniciou. */
    fun check(source: String, fileName: String = "<editor>"): List<PyIssue>? = runCatching {
        if (!Python.isStarted()) return null
        val arr = JSONArray(module().callAttr("check", source, fileName).toString())
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            PyIssue(
                o.getString("kind"), o.getString("type"), o.getString("msg"),
                o.getInt("line"), o.getInt("col"), o.getInt("end_line"), o.getInt("end_col"),
                o.optString("suggest")
            )
        }
    }.getOrNull()
}
