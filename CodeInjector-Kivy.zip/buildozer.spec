[app]
title = CodeInjector Kivy Runner
package.name = kivyrunner
package.domain = org.codeinjector
source.dir = .
source.include_exts = py,kv,png,jpg,jpeg,atlas,ttf,json,txt
version = 1.0.0
requirements = python3,kivy,pyjnius
orientation = portrait
fullscreen = 0
android.minapi = 24
android.archs = arm64-v8a
android.accept_sdk_license = True
p4a.bootstrap = sdl2

[buildozer]
log_level = 2
warn_on_root = 1
