# CodeInjector Kivy Runner

App companion separado para executar no Android os projetos Kivy enviados pela IDE CodeInjector. O package/application ID deve permanecer `org.codeinjector.kivyrunner`, porque a IDE usa esse identificador para abrir o app.

## Build pelo GitHub usando o celular

1. Crie um repositório para o Kivy Runner.
2. Envie **todo o conteúdo** deste ZIP para a raiz: `main.py`, `buildozer.spec`, `README.md` e `.github/workflows/build.yml`.
3. Abra **Actions → Build APK → Run workflow** ou faça um push.
4. Baixe o artefato `CodeInjector-Kivy-Runner-APK`, extraia o ZIP do artefato e instale o APK no celular.
5. Instale também o CodeInjector IDE. Quando um script com import Kivy for executado, a IDE enviará os arquivos de projeto ao runner.

O app usa Buildozer/python-for-android e Kivy com o bootstrap SDL2. O código enviado é executado como `__main__` em uma cópia temporária privada. As dependências adicionais que o seu projeto importa precisam ser adicionadas a `requirements` e o runner recompilado.

O workflow compila no GitHub Actions; não compila diretamente no Android. O projeto precisa de testes reais no aparelho após o build.
