"""CodeInjector Kivy Runner.

Recebe um ZIP compartilhado pelo CodeInjector, extrai o projeto num diretório
privado e executa o arquivo selecionado como __main__ dentro do processo Kivy.
"""
__version__ = "1.0.0"

import json
import os
from pathlib import Path, PurePosixPath
import runpy
import shutil
import sys
import traceback
import zipfile

EXTRA_PROJECT_URI = "org.codeinjector.runner.PROJECT_URI"
MANIFEST_PATH = "__codeinjector__/manifest.json"
MAX_ARCHIVE_BYTES = 64 * 1024 * 1024
MAX_UNPACKED_BYTES = 96 * 1024 * 1024
MAX_ARCHIVE_FILES = 500


def _android_activity():
    try:
        from jnius import autoclass
        return autoclass("org.kivy.android.PythonActivity").mActivity
    except Exception:
        return None


def _read_shared_archive(destination: Path) -> bool:
    """Copia a URI content:// recebida por Intent sem depender de permissões de storage."""
    activity = _android_activity()
    if activity is None:
        return False
    stream = None
    try:
        intent = activity.getIntent()
        uri = intent.getData()
        if uri is None:
            raw = intent.getStringExtra(EXTRA_PROJECT_URI)
            if raw:
                from jnius import autoclass
                uri = autoclass("android.net.Uri").parse(str(raw))
        if uri is None:
            return False

        from array import array
        from jnius import autoclass
        ByteArrayOutputStream = autoclass("java.io.ByteArrayOutputStream")
        stream = activity.getContentResolver().openInputStream(uri)
        if stream is None:
            raise RuntimeError("O Android não conseguiu abrir o arquivo compartilhado pela IDE.")
        output = ByteArrayOutputStream()
        buffer = array("b", [0] * 16384)
        total = 0
        while True:
            count = stream.read(buffer, 0, len(buffer))
            if count < 0:
                break
            total += count
            if total > MAX_ARCHIVE_BYTES:
                raise RuntimeError("O projeto compartilhado passou de 64 MB.")
            output.write(buffer, 0, count)

        # ISO-8859-1 mapeia cada byte a um caractere, permitindo recuperar os bytes sem perda.
        destination.write_bytes(str(output.toString("ISO-8859-1")).encode("latin-1"))
        return True
    finally:
        if stream is not None:
            try:
                stream.close()
            except Exception:
                pass


def _safe_extract(archive_path: Path, destination: Path) -> Path:
    if destination.exists():
        shutil.rmtree(destination, ignore_errors=True)
    destination.mkdir(parents=True, exist_ok=True)
    root = destination.resolve()
    unpacked = 0
    entries = 0
    with zipfile.ZipFile(str(archive_path), "r") as archive:
        for info in archive.infolist():
            if info.is_dir():
                continue
            name = info.filename.replace("\\", "/")
            parsed = PurePosixPath(name)
            if parsed.is_absolute() or not parsed.parts or any(part in ("", ".", "..") for part in parsed.parts):
                raise RuntimeError("O ZIP contém um caminho de arquivo inválido.")
            target = (destination / Path(*parsed.parts)).resolve()
            if target != root and root not in target.parents:
                raise RuntimeError("O ZIP tenta gravar fora da pasta do projeto.")
            entries += 1
            unpacked += info.file_size
            if entries > MAX_ARCHIVE_FILES or unpacked > MAX_UNPACKED_BYTES:
                raise RuntimeError("O projeto é muito grande para ser aberto no runner.")
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info, "r") as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst, length=64 * 1024)
    return destination


def _load_project(base_dir: Path):
    activity = _android_activity()
    files_dir = Path(str(activity.getFilesDir().getAbsolutePath())) if activity is not None else Path.cwd()
    files_dir.mkdir(parents=True, exist_ok=True)
    archive_path = files_dir / "codeinjector-project.zip"
    if not _read_shared_archive(archive_path):
        return None, None
    project_dir = files_dir / "codeinjector-project"
    _safe_extract(archive_path, project_dir)
    archive_path.unlink(missing_ok=True)

    manifest_file = project_dir / MANIFEST_PATH
    if not manifest_file.is_file():
        raise RuntimeError("O pacote enviado pela IDE não contém o manifesto do projeto.")
    manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
    entry = PurePosixPath(str(manifest.get("entry", "main.py")))
    if entry.is_absolute() or any(part in ("", ".", "..") for part in entry.parts):
        raise RuntimeError("O arquivo de entrada do projeto não é válido.")
    script = (project_dir / Path(*entry.parts)).resolve()
    if project_dir.resolve() not in script.parents or not script.is_file():
        raise RuntimeError("Não encontrei o arquivo Python selecionado no projeto.")
    return project_dir, script


def _message_app(title: str, message: str):
    from kivy.app import App
    from kivy.core.window import Window
    from kivy.uix.boxlayout import BoxLayout
    from kivy.uix.label import Label
    from kivy.uix.scrollview import ScrollView
    from kivy.uix.textinput import TextInput

    class RunnerMessageApp(App):
        def build(self):
            self.title = title
            root = BoxLayout(orientation="vertical", padding=18, spacing=10)
            root.add_widget(Label(text=title, size_hint_y=None, height="44dp", font_size="20sp"))
            scroll = ScrollView()
            text = TextInput(
                text=message, readonly=True, multiline=True,
                size_hint=(1, None), font_size="14sp",
                background_color=(0.08, 0.09, 0.13, 1),
                foreground_color=(0.91, 0.93, 0.97, 1),
                padding=12,
            )
            def resize_text(*_):
                text.height = max(scroll.height, text.minimum_height)
            text.bind(minimum_height=lambda *_: resize_text(), width=lambda *_: resize_text())
            scroll.add_widget(text)
            root.add_widget(scroll)
            return root

    Window.clearcolor = (0.055, 0.065, 0.09, 1)
    RunnerMessageApp().run()


def main():
    activity = _android_activity()
    try:
        project_dir, script = _load_project(Path.cwd())
        if script is None:
            _message_app(
                "CodeInjector Kivy Runner",
                "Este é o app companion de Kivy.\n\n"
                "Abra um arquivo Python no CodeInjector que use Kivy e toque em Executar.\n\n"
                "O editor envia uma cópia do projeto e este app executa o arquivo selecionado.",
            )
            if activity is not None:
                activity.finish()
            return
        os.chdir(str(project_dir))
        sys.path.insert(0, str(project_dir))
        sys.path.insert(0, str(script.parent))
        print("[CodeInjector Kivy Runner] Executando:", script)
        runpy.run_path(str(script), run_name="__main__")
        print("[CodeInjector Kivy Runner] Script encerrado.")
        if activity is not None:
            activity.finish()
    except BaseException:
        detail = traceback.format_exc()
        print("[CodeInjector Kivy Runner] Falha ao executar o script:\n" + detail)
        try:
            _message_app("Erro no projeto Kivy", detail[-14000:])
        except BaseException:
            traceback.print_exc()


if __name__ == "__main__":
    main()
